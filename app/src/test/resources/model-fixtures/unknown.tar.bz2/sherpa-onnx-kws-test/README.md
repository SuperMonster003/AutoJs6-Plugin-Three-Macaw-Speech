kws test
